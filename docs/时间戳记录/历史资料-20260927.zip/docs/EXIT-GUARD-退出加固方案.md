> 2026-09-26T22:06:13+08:00：本文件第11节为旧实施记录。用户现要求第一次X直接退出及可取消异常操作，最终实现与实际失败/修正/验证记录见 [EXIT-CANCEL-20260926.md](EXIT-CANCEL-20260926.md)，不再采用2.5秒关闭握手。

# 退出加固方案：程序必须永远关得掉，房主移交只做"尽力而为"

> 时间：2026-09-26 18:2x 起草；**18:59–19:02 已按第 10 节最小实现**（实施记录见第 11 节，随 `0.14.3-beta.6`）。
> 症状来源：用户实测 —— ① TURN 建不了公网连接时退不出；② 不开 TURN、网页端连不上时退不出；③ 移交房主失败时退不出。
> 结论先说：**根因是"关闭程序"被绑在了网络结果上**，而当前实现把"保住房间"放在了"用户能退出"之前。

## 1. 症状 → 代码定位（行号对当前 `main`）

| 症状 | 位置 | 机制 |
| --- | --- | --- |
| 移交失败就退不出 | `src/p2p.js:1613` | `await ack(this.local, 'room:migration-export', …)` 失败即 `throw`（:1614），一路抛到关闭握手 |
| TURN 建不了公网连接就退不出 | `src/p2p.js:1621` | 新房主 prepare 失败 → `throw '新房主未能恢复房间'`；`:1662` 另一处 `throw '…可重试退出'` |
| 抛错 = 拒绝关闭 | `src/useRoom.js:1039-1057` | 关闭握手回调里 `catch → closeReady({ ok:false })`（:1051） |
| `ok:false` 是**否决票** | `electron/main.cjs:513-526` | `if (result?.ok === false) return;`（:522）——主进程把关闭权交给了渲染层，失败就永远不关 |
| 网页端连不上就退不出 | 同上前两行 | 移交本身要靠房间服务/网页连接；那条链路不可用时失败结果恒定 → **每次重试都一样** |
| 20 秒计时器形同虚设 | `electron/main.cjs:508-511` | 到点只把自己那个 flag 清空，**不关闭窗口**；注释写着"超时不是销毁协调者的许可" |
| 再点一次 ✕ 也没用 | 同上 | 计时器已被清空 → 重新发一次 `before-close` → 再迁移一次 → 再失败；还可能**并发跑两套迁移** |
| 连 Alt+F4 / 自动更新也可能卡 | `electron/main.cjs:1199-1204` | `before-quit` 里 `Promise.allSettled([service.close(), webInvite?.stop(), closeObsCaptureEngine()]).finally(async () => { await clearChatSession(); app.quit(); })`：任一不 settle，就永不 `app.quit()` |

## 2. 现有超时链（最坏情况推导）

渲染层 `leave()`（`src/p2p.js:1553-1722`）里每一步其实**都有**时限（`ack` 默认 15 秒，见 `src/lib.js:408-417`）：

```
probe 各成员 3s（并发）
→ ack room:migration-export      15s（默认值！失败即抛）
→ sendControl migration:prepare   8s
→ sendControl migration:arm       3s
→ 各成员 migration:commit          3s（并发）
→ ack room:leave                 15s（已被 catch 吞掉）
≈ 最坏 44 秒
```

而主进程的关闭握手期限是 **20 秒**、到点却什么都不做。也就是说：

- **成功**时：最多要等 44 秒（期间界面上毫无反馈），20 秒后那次点击已"过期"，要等渲染层迟到的 `ok:true` 才真正关闭；
- **失败**时：`ok:false` → 永久拒绝关闭，用户只能去任务管理器。

三个症状其实是同一件事：**退出路径上串了一长串网络操作，其中任何一环失败都会否决退出，而失败原因（TURN/网页端不可达）通常不会自己恢复。**

## 3. 设计原则

1. **退出必须是无条件的本地操作**：不等待任何网络结果；网络清理只做"尽力而为"。
2. **移交有硬期限**：客户端 ≤2.5 秒；到期即降级为"房间已关闭"，如实告知，而不是拒绝退出。
3. **每次请求都要有出口**：任何 `await` 都不会挡住退出；关窗/退出各有独立看门狗。
4. **逃生口不止一个**：期限内再点一次 ✕ ＝ 立刻强退；主进程另有硬通道（`app.exit`）。

## 4. 已核实的关键事实（决定了"降级"是安全的）

**服务端在房主 socket 断开且没完成两阶段迁移时，会直接关闭房间**（`server/rooms.mjs:734-789`）：
删除房间、给其余成员发 `room:kicked`「房主连接异常中断；未完成安全迁移，房间已关闭。」、调用 `onRoomClosed`。
所以"客户端不再死等移交"**不会留下僵尸房间**，代价只是房间里其他人会被踢出来 —— 这是可接受的取舍。

另外：`rooms.mjs:16` 服务端自己还有 `MIGRATION_TIMEOUT_MS = 45_000`，与新客户端的 2.5 秒期限并不冲突（服务端逻辑不需要改，向后兼容旧客户端）。

## 5. 改动点

### 5.1 渲染层：把移交改成"有界 + 失败降级"

| 文件:行 | 现状 | 改成 |
| --- | --- | --- |
| `src/p2p.js:1613` | `ack(…, 'room:migration-export', …)` 用默认 15 秒 | 显式 `1500ms` |
| `src/p2p.js:1616-1620` | prepare 8 秒 | `1500ms` |
| `src/p2p.js:1651-1656` | arm 3 秒 | `1000ms` |
| `src/p2p.js:1687-1701` | commit 3 秒 | `800ms` |
| `src/p2p.js:1614 / 1621 / 1633 / 1662` | 四处 `throw` | **不抛**：统一走 `:1630-1648` 已有的降级分支（`disconnect()` + `{ok:true, closed:true, reason:'移交未完成，房间已关闭'}`） |
| `src/p2p.js:1553` | `leave()` 无总期限 | 用本文件里现成的 `withTimeout`（定义在 `p2p.js:122`，`:2209` 已在用）再包一层 **2500ms 总期限**，超时同样走降级 |
| `src/useRoom.js:1039-1057` | 失败回 `ok:false` | **永远回 `ok:true`**；把结果（`migratedTo` / `closed` / `reason`）交给界面提示 |
| `src/useRoom.js:419-454` | — | 不变（`leave(true)` 的快速路径已经正确，卸载时使用） |

**提示文案（三选一，如实说明）**：`已把房主移交给 X` / `其他成员无法接管，房间已关闭` / `移交超时，房间已关闭`。

### 5.2 主进程：三层保护（`electron/main.cjs`）

| 位置 | 改动 |
| --- | --- |
| `:496-512` 窗口 `close` | ① 期限 **2.5 秒**（与渲染层一致）到点**无条件** `forceWindowClose = true; window.close()`；② 期限内**再点一次 ✕ → 立即强退**（记录首次请求时间）；③ 只允许一个进行中的握手，避免并发迁移 |
| `:513-526` `close-ready` | `ok:false` 不再否决：写日志（`quit fallback: <reason>`）+ 若已过期则忽略 |
| `:1199-1204` `before-quit` | 新增 **5 秒硬看门狗** `setTimeout(() => app.exit(0), 5000)`；`clearChatSession()` 包 1 秒期限；收尾完成后 `app.exit(0)`（`app.exit` 不再触发 `before-quit`，保证一定走掉） |
| 新增 `requestQuit(reason)` | X / Alt+F4 / `window-all-closed`(:1198) / 单实例(:187) / 更新管线 全部走同一入口，时限一致 |
| `session-end`（Windows 关机） | 新增：**不做任何网络等待**，直接退出 |
| `:656-694` 更新管线 | `waitForMainWindowClose(25000)` 保持不变；关窗修好后它自然不再超时 |

### 5.3 服务端：`close()` 不能无限等（`server/index.mjs:399-428`）

现状：`rooms.close()` → `io.close(cb)` → `server.close(cb)`。**`server.close()` 会等所有连接结束**，
网页观众/keep-alive 长连接会让它永不回调 → `before-quit` 的 `.finally` 永远不到 → 退不出。

改：`close()` 里先 `io.disconnectSockets(true)`，再 `server.closeAllConnections?.()`（Node 18+），然后再 `close()`
—— 同时保留主进程 5 秒看门狗作为第二层兜底（进程退出本来就会断开所有 socket）。

## 6. 与自动更新的交叉影响

更新管线在 `phase: 'closing'` 时靠"主窗口消失"推进（`main.cjs:656-694`，25 秒上限）。
**当前只要关闭握手被否决，自动更新也会一起卡住**（会看到更新窗口停在"正在更新"然后超时失败）。
本方案修好后，这条路径同时得到修复 —— 更新验收清单里的"关闭正在运行的程序"一步也会更可靠。

## 7. 测试与验收

**单测（`node --test`，可注入假 socket / 假 service / 假计时）**

1. `leave()` 在 `migration-export` 超时或 `ok:false` 时：**不抛错**，返回 `{ok:true, closed:true}`，且 `disconnect()` 被调用。
2. `leave()` 在最坏情况下总耗时 ≤ 3 秒。
3. 正常移交仍然返回 `migratedTo`（不回归）。
4. 主进程连续两次 `close` 事件 → 第二次立即强制关闭。
5. `before-quit` 里 `service.close()` 永不 resolve → 5 秒内调用 `app.exit(0)`。

**E2E（复用 `scripts/check-auto-update.cjs` 的 CDP 基础设施）**

6. 建房 + 一个不应答的"观众" → 触发关闭 → 断言进程在 ~4 秒内消失（网页端连不上时同样成立）。

**手工（真机，最容易复现你报的三个场景）**

7. 阻断 TURN/UDP 或关掉网页端连接 → 建房 → 手机加入 → 点 ✕ → **≤3 秒退出**并提示"移交未完成，房间已关闭"。
8. 同样场景下 **再点一次 ✕ → 立刻退出**（不等 3 秒）。
9. 正常场景：两人房间、另一人可达 → 点 ✕ → 提示"已把房主移交给 X"，房间继续存在。

## 8. 取舍与默认行为

- **核心取舍**：退出时房间可以被牺牲。用户可以随时离开；"房间继续存在"只是加分项。
- 建议新增设置项（默认开）：「退出时优先把房主移交给其他成员（最多等 3 秒）」—— 关掉即立刻退出、房间直接结束。
- 文案建议：服务端那句「房主连接异常中断；未完成安全迁移，房间已关闭。」改为中性表述
  （例如「房主已离开，房间已关闭。」），因为这条路径现在会成为**正常退出**的一部分，不再是异常。

## 9. 风险与未决

1. 降级路径会踢掉房间里其他成员 —— 需要接受，且文案要说清（见第 8 节）。
2. 后台"半迁移"：超时后必须**立即断开**，不能留一个还在跑迁移的连接（否则新房主可能拿到一个旧协调器）。
3. 旧客户端（已发布的 beta.5 及更早）仍然是"移交失败即退不出" —— 本次修复只能随下一个版本生效；
   要不要为此单独发一个版本，由用户决定。
4. 便携单文件 EXE 的退出路径未实测（与更新路径同一类空白）。

## 10. 实施顺序（原计划，已完成前两步）

1. **渲染层**：`p2p.js` 有界移交 + 失败降级、`useRoom.js` 永远回 `ok:true`（+ 单测 1-3）。
2. **主进程**：`close` 双层期限 + 二次点击强退 + `before-quit` 看门狗 + 统一 `requestQuit`（+ 单测 4-5）。
3. **服务端**：`close()` 主动断开连接 + 文案中性化（+ E2E 6、手工 7-9）。← **本轮未做，理由见 11.3**

## 11. 实施记录（2026-09-26 18:59–19:02，随 `0.14.3-beta.6`）

按第 10 节的顺序做了**最小实现**，差异点如实登记如下。

### 11.1 渲染层

| 文件:位置 | 实际改法 |
| --- | --- |
| `src/p2p.js` `leave()`（导出候选拒绝分支） | `if (!result.ok) throw …` → **记下 `prepareError` 并 `continue`**（换下一个候选人） |
| `src/p2p.js` `leave()`（没有候选人成功） | 不再 `throw prepareError`；统一 `disconnect()` + 返回 `{ok:true, closed:true, reason:'移交未能完成（原因），房间已关闭。'}` |
| `src/p2p.js` `leave()`（新房主未确认 arm） | 不再抛「…可重试退出」；改为 `migration:abort` → `disconnect()` → 返回 `{ok:true, closed:true, reason:'新房主未确认接管（原因），房间已关闭。'}` |
| `src/useRoom.js` 关闭握手 | `leave()` 外面加 **2 秒** 上限（`Promise.race`）；无论成功/失败/超时都回 `closeReady({ ok:true, migratedTo, closed, reason })`，**再没有 `ok:false`** |

### 11.2 主进程（`electron/main.cjs`）

| 项 | 实际改法 |
| --- | --- |
| 关闭预算 | 新增 `CLOSE_GRACE_MS = 2500`；`closeHandshakeTimer` 到点**无条件** `forceWindowClose = true; window.close()`（旧代码到点只是把 flag 清空） |
| 二次点击 | 记录 `closeRequestedAt`；**2.5 秒内再点一次 ✕** 直接强制关闭 |
| `close-ready` | `ok:false` 不再 `return`（否决）——只 `console.warn` 记录原因，随后照样关窗 |
| 退出看门狗 | 新增 `EXIT_GRACE_MS = 5000`：`before-quit` 里起 `setTimeout(() => app.exit(0), 5000)`；收尾用 `Promise.race([clearChatSession(), 1 秒])` 限时；最终用 **`app.exit(0)`** 而不是 `app.quit()`（`exit` 不会再触发 `before-quit`，保证一定走掉） |

### 11.3 本轮**没有**做（避免夹带）

- **服务端 `server/index.mjs` 的 `close()`** 没有改（原计划的"主动断开连接 + `closeAllConnections`"）。理由：主进程 5 秒看门狗已经覆盖"`server.close()` 等长连接永不回调"这一风险；少改一处服务端代码，回归面更小。
- **`session-end`（Windows 关机）** 未单独处理。
- **设置项**「退出时优先移交（最多等 N 秒）」未加：本次直接采用固定 2.5 秒预算。
- **文案中性化**：服务端 `rooms.mjs:764` 那句「房主连接异常中断；未完成安全迁移，房间已关闭。」**未改**。它现在会出现在"正常退出但移交失败"的场景里，措辞偏负面，建议下一版改成「房主已离开，房间已关闭。」（一行改动，未做是为了不扩大本轮范围。）

### 11.4 验证

- `tests/migration-close.test.mjs` **重写**：新增断言"`ok:false` 不再阻止关闭"、"2.5 秒内再点一次立即关闭"、"无人应答时到点自动关闭"；旧用例（断言"失败就保持窗口打开"）按新策略替换。
- `tests/p2p-migration.test.mjs` 的 `commitFailure` 场景**重写**：由"`leave()` 必须抛错且房主留在房间"改为"`leave()` 返回 `closed:true` 且**没有任何成员被错误迁移**"。
- `npm test` **191/191 通过**；`npm run check` 全绿（含网络架构静态自检）。
- **真机未验证**：需要一次"阻断 TURN/UDP → 建房 → 手机加入 → 点 ✕"的手工测试（预期 ≤3 秒退出，提示"移交未完成，房间已关闭"，再点一次立即退）。
